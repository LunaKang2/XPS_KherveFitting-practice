# XPS F 1s Streamlit Web App (Independent SciPy PoC)

이 파일은 [LunaKang2/XPS_KherveFitting-practice](https://github.com/LunaKang2/XPS_KherveFitting-practice)의
`xps_automation_poc.py`를 바탕으로 만든 독립적인 **연구용 F 1s 피팅 웹 인터페이스**입니다.
원본 코드를 대체하거나 KherveFitting/CasaXPS 결과와의 동일성을 보장하지 않습니다.

## 중요한 구분

- **현재 가능한 것:** CSV/ZIP 업로드, F 1s 1-peak / 2-peak 피팅 비교, iterative Shirley 및 product GL, R²/RMSE/AICc/BIC, 그래프/CSV/JSON 다운로드.
- **아직 불가능한 것:** C/O/F/Li/P 스펙트럼의 통합 해석, 화학종 자동 식별, 물질 존재 판단, 전문가 검증된 정량분석.
- 초기값은 F 1s 685.1 / 688.5 eV, FWHM 0.6~4 eV. 시료와 에너지 보정 상태에 따라 사용자가 변경해야 합니다.
- 이 앱의 모든 분석 계산은 Python/SciPy 기반이며, 별도 LLM/AI agent가 아닙니다.

## A. GitHub에 파일 추가하기 (가장 간단한 경로)

1. `XPS_Streamlit_Deploy.zip` 압축을 풉니다.
2. [기존 GitHub 저장소](https://github.com/LunaKang2/XPS_KherveFitting-practice)로 갑니다.
3. `Add file` → `Upload files`에서 다음 파일을 **저장소 루트(root)**에 업로드합니다.
   - `streamlit_app.py`
   - `xps_engine.py`
   - `requirements.txt`
   - 선택: `example_F1s_synthetic.csv`, `.streamlit/config.toml` (숨김 폴더는 웹 업로드가 어려울 수 있어 생략 가능)
4. `Commit changes`를 클릭합니다. 기존 `xps_automation_poc.py` 파일은 그대로 보존합니다.

> 참고: ZIP 자체를 GitHub에 그대로 올리기만 하면 Streamlit이 내부 Python 파일을 자동으로 실행하지 않습니다. 압축을 풀어 각각 업로드해야 합니다.

## B. 별도 PC 없이 Streamlit Community Cloud에서 배포

1. https://share.streamlit.io 에 GitHub 계정으로 로그인합니다.
2. `Create app` → `Yup, I have an app`을 선택합니다.
3. `Repository` = `LunaKang2/XPS_KherveFitting-practice`
4. `Branch` = `main`
5. `Main file path` = `streamlit_app.py`
6. `Deploy`를 누릅니다. 배포가 완료되면 `*.streamlit.app` 주소가 생성됩니다.
7. URL로 접속해서 합성 데모 데이터를 확인하고, 실제 `F1s.csv`를 올려 봅니다.

이 방법은 기존 `surface.tailc97432.ts.net` 주소를 복원하는 것이 아니라 **새로운 공개 주소를 생성**하는 방법입니다.
일반 사용자도 사이트에 접근하도록 공개 배포하면, 연구실 기밀 데이터 및 권한 설정에 주의해야 합니다.

## C. Windows PC에서 로컬 테스트

PowerShell에서 (파일이 있는 폴더에서) 아래 명령어를 실행합니다.

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run streamlit_app.py
```

브라우저에서 http://localhost:8501 열기.

## CSV 형식

```csv
Binding Energy (eV),Intensity (CPS)
684.0,12000
684.1,12150
...
```

실제 파일은 최소 20개 이상의 BE 값이 필요합니다. ZIP을 올린 경우 내부 CSV 목록 중 F 1s 파일을 선택합니다.

## 기존 BE correction 확인

이전에 Excel 단계에서 F 1s +0.32 eV 등의 보정이 적용되었다면, 이미 보정된 CSV에는 다시 +0.32를 입력하지 마세요.
웹앱의 `추가 BE offset` 기본값은 **0.00 eV**입니다. 데이터 포맷의 유효성 검증은 화학적 보정 검증과 별개입니다.

## 재현성 / 방법론 제한

- Background: 원본 PoC의 iterative Shirley approximation. 최적화 중 **고정**되므로 배경의 파라미터 불확실성은 품질 지표에 반영되지 않습니다.
- GL: `gaussian ** (1-lorentz_fraction) * lorentzian ** lorentz_fraction`인 product profile. KherveFitting의 라인형상 파라미터와 동일하다고 가정할 수 없습니다.
- AICc/BIC: 정규/독립/동분산 잔차를 사실상 전제하고 파라미터 수로 페널티를 계산합니다. 모델 선택의 참고 지표이지 화학적 존재 판정 근거가 아닙니다.
- 피크 면적은 데이터가 제공된 BE 범위에서 수치적으로 적분한 값입니다.
- 면적을 원자농도로 환산하려면 적절한 RSF 등 별도 보정이 필요합니다.

## 파일 구조

```
streamlit_app.py             # 웹 인터페이스 및 다운로드
xps_engine.py               # 피팅/데이터 처리 함수
requirements.txt            # 클라우드 설치 의존성
example_F1s_synthetic.csv   # 합성 데모 데이터, 실험 데이터 아님
.streamlit/config.toml      # 선택: 업로드 용량/테마 설정
tests/test_xps_engine.py    # 기본 과학/입력/적분 관련 자동 테스트
README_DEPLOY.md            # 배포 설명서
```
