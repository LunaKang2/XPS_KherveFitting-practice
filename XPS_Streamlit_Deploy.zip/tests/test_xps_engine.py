import io
import zipfile
import numpy as np
from xps_engine import (
    gl, shirley, parse_csv, make_synthetic_f1s,
    zip_csv_names, extract_zip_csv, fit_model, fit_comparison, serializable_report,
)


def test_gl_normalization_and_fwhm():
    x = np.array([684.0, 685.0, 686.0])
    y = gl(x, 685.0, 2.0, 100.0, .35)
    assert abs(y[1] - 100.0) < 1e-9
    assert abs(y[0] - 50.0) < 1e-9
    assert abs(y[2] - 50.0) < 1e-9


def test_parse_and_zip():
    raw = make_synthetic_f1s()
    x, y = parse_csv(raw)
    assert len(x) == 315
    assert np.all(np.diff(x) > 0)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        z.writestr('example/other.csv', raw)
        z.writestr('F1s.csv', raw)
    names = zip_csv_names(buf.getvalue())
    assert names[0] == 'F1s.csv'
    x2, y2 = parse_csv(extract_zip_csv(buf.getvalue(), names[0]))
    np.testing.assert_allclose(x, x2)
    np.testing.assert_allclose(y, y2)


def test_duplicate_be_handling():
    raw = 'Binding Energy (eV),Intensity (CPS)\n' + ''.join(
        f'{i},{i*10}\n' for i in range(30)) + '5,70\n'
    x, y = parse_csv(raw.encode())
    assert len(x) == 30
    assert y[5] == 60.0


def test_two_peak_fit_with_exact_fixed_background():
    x = np.linspace(682, 693, 300)
    bg = np.linspace(9000, 12000, len(x))
    y = bg + gl(x, 685.1, 1.9, 110000, .35) + gl(x, 688.5, 2.2, 40000, .20)
    one = fit_model(x, y, bg, [685.1], 1.5)
    two = fit_model(x, y, bg, [685.1, 688.5], 1.5)
    assert two['success']
    assert two['metrics']['rmse'] < 0.1
    assert two['metrics']['aicc'] < one['metrics']['aicc']
    assert abs(two['peaks'][0]['center_eV'] - 685.1) < 0.02
    assert abs(two['peaks'][1]['center_eV'] - 688.5) < 0.02


def test_end_to_end_synthetic():
    raw = make_synthetic_f1s()
    x, y = parse_csv(raw)
    bg, results = fit_comparison(x, y, 685.1, 688.5, 1.5)
    assert len(results) == 2
    assert np.all(np.isfinite(bg))
    assert results[0]['success'] and results[1]['success']
    assert results[1]['metrics']['aicc'] < results[0]['metrics']['aicc']
    result = serializable_report(x, y, 'synthetic.csv', raw, 0.0, 685.1, 688.5, 1.5, results)
    assert len(result['source_sha256']) == 64
    assert len(result['models']) == 2
    assert 'component' not in result['models'][1]['peaks'][0]
